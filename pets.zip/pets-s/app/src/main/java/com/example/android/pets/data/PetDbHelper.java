package com.example.android.pets.data;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.android.pets.data.PetContract.PetEntry;

/**
 * Created by Abdulrhman on 12/10/2016.
 */
public class PetDbHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "shelter.dp";
    public static final int DATABASE_VERSION = 1;

    // Create Table SQL Command
    public static final String SQL_CREATE = "CREATE TABLE  " + PetEntry.TABLE_NAME + " ( " + PetEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + PetEntry.COLUMN_NAME + " TEXT NOT NULL , "
            + PetEntry.COLUMN_BREED + " TEXT , " + PetEntry.COLUMN_GENDER + "  INTEGER NOT NULL , " + PetEntry.COLUMN_weight + " INTEGER NOT NULL DEFAULT 0 );";

    //delete Table SQl Command
    public static final String SQL_DELETE = "DROP TABLE IF EXISTS " + PetEntry.TABLE_NAME;


    //constractor
    public PetDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        Log.d("LOGLOG", SQL_CREATE);
        sqLiteDatabase.execSQL(SQL_CREATE);


    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

        //to drop or delete the old table to create new one
        sqLiteDatabase.execSQL(SQL_DELETE);
        //call onCreate method to create a new table with new Version number
        onCreate(sqLiteDatabase);


    }
}
