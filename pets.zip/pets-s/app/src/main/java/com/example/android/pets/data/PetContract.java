package com.example.android.pets.data;

import android.provider.BaseColumns;

/**
 * Created by Abdulrhman on 12/10/2016.
 */
public final class PetContract {


    public static class PetEntry implements BaseColumns {


        //table name , then table's columns header name
        public static String TABLE_NAME = "pets";
        //headers names
        public static String COLUMN_ID = BaseColumns._ID;
        public static String COLUMN_NAME = "name";
        public static String COLUMN_BREED = "breed";
        public static String COLUMN_GENDER = "gender";
        public static String COLUMN_weight = "weight";


        //constants for gender
        public static int GENDER_MALE = 1;
        public static int GENDER_FEMALE = 2;
        public static int GENDER_UNKNOWN = 0;


    }





}
